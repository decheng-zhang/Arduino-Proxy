#!/usr/bin/perl -w
use Device::SerialPort;
use Cwd qw(getcwd);
my $port = Device::SerialPort->new("/dev/ttyACM0")
    || die "Cannot open port\n";

$port->databits(8);
$port->baudrate(9600);
$port->parity("even");
$port->stopbits(1);
my $wkdir = getcwd();
while(1) {
    my $ch = $port->read(1);
    if($ch){
	$| = 1;
	print "Rec: $ch ->>>>>>>>>>>>>>>>>>>>>>>>>>>\n";
	chdir "$wkdir";
	my $status = system("/home/dzhang/bin/nunaliit", "update") if($ch eq "n");
	if (($status >>= 8) != 0) {
	    $| = 1;
	    print "Update failed.\n";
	} else {
	    $| = 1;
	    print "Update Succeed.\n";
	}
    } 
#    sleep(1);
}
